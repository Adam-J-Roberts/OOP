#ifndef Simulation_H
#define Simulation_H


class Simulation
{
    private:
      Board* sim;                               /*Pointer to Board object*/

    public:
        Simulation(int hunters, int prey);
         /**************************************************************
        * Description:  Simulation constructor
        * Parameters:   No parameters required
        * Return Value: New Simulation
        **************************************************************/       


};
#endif