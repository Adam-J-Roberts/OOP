#ifndef PREDATOR_H
#define PREDATOR_H
#include "Animal.h"


class Predator : public Animal
{
    

    private:
        
      
        void eat(int i, int j);
        /**************************************************************
        * Description:  Agent eatting method
        * Parameters:   Int X and Y locations of agent
        * Return Value: Void
        **************************************************************/
        Animal* adjacent(int i, int j);
        /**************************************************************
        * Description:  Checks adjecent cells for other agents
        * Parameters:   Int X and Y locations of agent
        * Return Value: Animal*
        **************************************************************/
        void breed(int i, int j);
        /**************************************************************
        * Description:  Causes agent to reproduce
        * Parameters:   Int X and Y locations of agent
        * Return Value: Void
        **************************************************************/
        void move(int i, int j);
         /**************************************************************
        * Description:  Moves Agent
        * Parameters:   Int X and Y locations of agent
        * Return Value: Void
        **************************************************************/       
        void die(int i, int j);
        /**************************************************************
        * Description:  Kills agent
        * Parameters:   Int X and Y locations of agent
        * Return Value: Void
        **************************************************************/        

    public:
    Predator();
        /**************************************************************
        * Description:  Predator constructor
        * Parameters:   No parameters required
        * Return Value: New Predator
        **************************************************************/

};
#endif