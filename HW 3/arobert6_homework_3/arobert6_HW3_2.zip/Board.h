#ifndef Board_H
#define Board_H



class Animal;
using namespace std; // Don't do this! Remove before handing in

class Board
{
    friend class Animal;
    private:
        const int size;                         /*Integer dictating size of board*/
        int timeStep;                           /*Total number of steps simulator has taken*/
        Animal*** board;                        /*Pointer for referencing the 2d board*/

        void stepForward();
        /**************************************************************
        * Description:  Steps forward in time moving the agents
        * Parameters:   No parameters required
        * Return Value: Void
        **************************************************************/
        void print();
        /**************************************************************
        * Description:  Prints out a display of the board
        * Parameters:   No parameters required
        * Return Value: Void
        **************************************************************/        
        void generatePredators(int hunters);
        /**************************************************************
        * Description:  Generates predators on the board
        * Parameters:   NUmber of hunters
        * Return Value: Void
        **************************************************************/
        void generatePrey(int hunted);
        /**************************************************************
        * Description:  Generates predators on the board
        * Parameters:   Number of hunted
        * Return Value: Void
        **************************************************************/
        void generateBoard();
        /**************************************************************
        * Description:  Produces board based on number of agents
        * Parameters:   No parameters required
        * Return Value: Void
        **************************************************************/        

    public:
        
        Board(int hunters, int hunted);
        /**************************************************************
        * Description:  Causes agent to reproduce
        * Parameters:   Int X and Y locations of agent
        * Return Value: Void
        **************************************************************/
        friend class Animal;
        //friend class Simulation;

};
#endif
