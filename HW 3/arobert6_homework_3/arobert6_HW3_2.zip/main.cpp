#include <cstdlib>

#include "Animal.h"
#include "Prey.h"
#include "Predator.h"
#include "Board.h"
#include "Simulation.h"


using namespace std;

int main()
{
    Simulation* steve = new Simulation(3,2);

return 0;
}