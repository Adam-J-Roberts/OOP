#include "Animal.h"
#include "Predator.h"
#include "Prey.h"
#include "Board.h"
#include <cstdlib>
#include <math.h>


Board::Board(int hunters, int hunted) 
    : size(3)//sqrt((hunters*5)+(hunted*5)))
{
    srand(time(NULL));
    int preditors = hunters;
    int prey = hunted;
    generateBoard();
    generatePredators(preditors);
    generatePrey(prey);

    print();
}
void Board::print(){
    for(int i=0; i<size; i++){
        for(int j=0; j<size; j++){
            if(board[i][j]!=NULL){
                cout << board[i][j]->getIdentity() << " ";
            }
            else{cout << board[i][j] << " "; }
            
        }
        cout << endl;
    }
    cout << endl; 
}
void Board::generateBoard(){
    board = new Animal**[size];
    for(int i = 0; i < size; i++){
        board[i] = new Animal*[size];
    }
    for(int i = 0; i < size; i++){
        for(int j=0; j<size; j++){
            board[i][j]=NULL;
        }
    } 
}
void Board::generatePredators(int hunters){
        for(int i=0; i < hunters; i++){
        bool stop = false;
        do{
            int x = rand() % (size) + 0;
            int y = rand() % (size) + 0;
            if(board[x][y] == NULL){
                Animal* temp = new Predator();
                board[x][y] = temp;
                stop = true;
            }
            else{
                stop = false;
            }
        }while(stop==false);
    }
}
void Board::generatePrey(int hunted){
    for(int j=0; j < hunted; j++){
        bool stop = false;
        do{            
            int x = rand() % (size) + 0;
            int y = rand() % (size) + 0;
            if(board[x][y] == NULL){
                Animal* temp = new Prey();
                board[x][y] = temp;
                stop = true;
            }
            else{
                stop = false;
            }
        }while(stop==false);
    }
}
void Board::stepForward(){
    /*timeStep++;
    cout << "Step:" << timeStep << endl;;
    for(int i=0;i<size;i++){
        for(int j=0; j<size;j++){            
            if(board[i][j] != NULL && board[i][j]->getTurns() != timeStep) 
            {   
                
                if(board[i][j]->getIdentity() == 'v'){
                    //board[i][j]->eat(i,j);
                    
                    if (board[i][j]->getEatTurns()==4){
                       //board[i][j]->die(i,j);
                    }
                    if(board[i][j] != NULL){
                        if(board[i][j]->getLaidTurns() == 8){
                            //board[i][j]->breed(i,j);
                        }
                        //board[i][j]->move(i,j);
                    }
                }
            }
        }
    }*/
}
