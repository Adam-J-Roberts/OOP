#include "Animal.h"
#include "Predator.h"

Predator::Predator()
{
    steps = 0;
    identity = 'v';
    turns = 0;
    laidTurns = 0;
    eatTurns = 0;


}
void Predator::eat(int i, int j){
        /*if(adjacent(i,j)==NULL){  }
        else{
            if(j>0 && sim.board[i][j-1]!=NULL && sim.board[i][j-1]->getIdentity() == 'p' ){ sim.board[i][j-1] = NULL; sim.board[i][j-1]->setEatTurns( 0 ); }
            else if(j<size-1 && sim.board[i][j+1]!=NULL && sim.board[i][j+1]->getIdentity() == 'p'){ sim.board[i][j+1] = NULL; sim.board[i][j-1]->setEatTurns( 0 ); }
            else if(i > 0 && sim.board[i-1][j]!=NULL && sim.board[i-1][j]->getIdentity() == 'p'){ sim.board[i-1][j] = NULL; sim.board[i][j-1]->setEatTurns( 0 ); }
            else if(i<size-1 && sim.board[i+1][j]!=NULL && sim.board[i+1][j]->getIdentity() == 'P'){ sim.board[i+1][j] = NULL; sim.board[i][j-1]->setEatTurns( 0 ); }
        }*/
}
Animal* Predator::adjacent(int i, int j){
    /*
        if(j>0 && board[i][j-1]!=NULL){ return board[i][j-1]; }//
    else if(j<size-1 && board[i][j+1]!=NULL){ return board[i][j+1]; }//
    else if(i > 0 && board[i-1][j]!=NULL){ return board[i-1][j]; }//
    else if(i<size-1 && board[i+1][j]!=NULL){ return board[i+1][j]; }
    else{ return NULL; }*/
    return NULL;
}

void Predator::breed(int i, int j){
        /*
        if(j>0 && board[i][j-1]==NULL){ board[i][j-1] = new Predator(); board[i][j]->setLaidTurns(0); }
        else if(j<size-1 && board[i][j+1]==NULL){ board[i][j+1] = new Predator(); board[i][j]->setLaidTurns(0); }
        else if(i > 0 && board[i-1][j]==NULL){ board[i-1][j] = new Predator(); board[i][j]->setLaidTurns(0); }
        else if(i<size-1 && board[i+1][j]==NULL){ board[i+1][j]= new Predator(); board[i][j]->setLaidTurns(0); }
        else{ }*/
}

void Predator::move(int i, int j){
    /*int choice = (rand() % 4) + 1;
    bool moveOn = false;
    if(board[i][j]->getIdentity()=='v'){
            do { 
                    switch(choice) {
                        case 1 :
                            if( j>0 && board[i][j-1]==NULL ){ 
                                    board[i][j]->setEatTurns(board[i][j]->getEatTurns()+1);
                                    board[i][j]->setLaidTurns(board[i][j]->getLaidTurns()+1);
                                    board[i][j-1] = board[i][j]; 
                                    board[i][j] = NULL;
                                    moveOn = true;
                                    board[i][j-1]->setTurns(timeStep);

                            }
                            else{
                                choice = (rand() % 4) + 1; 
                            }

                            break;
                            
                        case 2 :
                            if(j!=size-1 && board[i][j+1]==NULL){
                                board[i][j]->setEatTurns(board[i][j]->getEatTurns()+1);
                                board[i][j]->setLaidTurns(board[i][j]->getLaidTurns()+1);
                                board[i][j+1] = board[i][j]; 
                                board[i][j] = NULL;
                                moveOn = true;
                                board[i][j+1]->setTurns(timeStep);
                            }
                            else{
                                choice = (rand() % 4) + 1;  
                            }
                            break;
                        case 3 :
                            if(i > 0 && board[i-1][j]==NULL){
                                board[i][j]->setEatTurns(board[i][j]->getEatTurns()+1);
                                board[i][j]->setLaidTurns(board[i][j]->getLaidTurns()+1);
                                board[i-1][j] = board[i][j]; 
                                board[i][j] = NULL;  
                                moveOn = true;
                                board[i-1][j]->setTurns(timeStep);
                            }
                            else{
                                choice = (rand() % 4) + 1;   
                                }
                            break;
                        case 4 : 
                            if(i!=size-1 && board[i+1][j]==NULL){ 
                                board[i][j]->setEatTurns(board[i][j]->getEatTurns()+1);
                                board[i][j]->setLaidTurns(board[i][j]->getLaidTurns()+1);
                                board[i+1][j] = board[i][j];
                                board[i][j] = NULL;
                                moveOn = true;
                                board[i+1][j]->setTurns(timeStep); 
                            }
                            else{
                                choice = (rand() % 4) + 1;
                                } 
                            break;                
                }   
            
            } while (moveOn == false);*/
}

void Predator::die(int i, int j){
     /*if (board[i][j]->getEatTurns()==4){
        delete board[i][j];
        board[i][j]=NULL;
    }*/
}
