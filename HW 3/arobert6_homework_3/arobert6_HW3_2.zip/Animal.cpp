#include "Animal.h"


Animal::Animal(){
    this->steps = 0;
    this->identity = identity;
    this->turns = 0;
    laidTurns = 0;
}
void Animal::setIdentity(char identity){
    this->identity=identity;
}
char Animal::getIdentity(){
    return identity;
}
int Animal::getTurns(){
    return turns;
}
void Animal::setTurns(int timeStep){
    turns = timeStep;
}
Animal* Animal::adjacent(int i, int j){
return NULL;
}
void Animal::eat(int i, int j){

}
int Animal::getLaidTurns(){
    return laidTurns++;
}
void Animal::setLaidTurns(int laidTurns){
    this->laidTurns=laidTurns;
}
int Animal::getEatTurns(){
    return eatTurns;
}
void Animal::setEatTurns(int eat){
    eatTurns = eat;
}
void Animal::breed(int i, int j){
  
}