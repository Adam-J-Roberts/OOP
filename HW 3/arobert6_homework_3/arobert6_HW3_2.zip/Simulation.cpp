#include "Animal.h"
#include "Predator.h"
#include "Prey.h"
#include "Board.h"
#include "Simulation.h"

Simulation::Simulation(int hunters, int prey){
        sim = new Board(hunters,prey);
        

}