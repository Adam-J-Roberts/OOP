#include "Animal.h"
#include "Prey.h"

//Prey::Prey(){}
Prey::Prey()
{
    steps = 0;
    identity = 'p';
    turns = 0;
    laidTurns = 0;
    eatTurns = 0;
}
Animal* Prey::adjacent(int i, int j){
    /*if(j>0 && sim.board[i][j-1]!=NULL){ return sim.board[i][j-1]; }//
    else if(j<size-1 && sim.board[i][j+1]!=NULL){ return sim.board[i][j+1]; }//
    else if(i > 0 && sim.board[i-1][j]!=NULL){ return sim.board[i-1][j]; }//
    else if(i<size-1 && sim.board[i+1][j]!=NULL){ return sim.board[i+1][j]; }
    else{ return NULL; }*/

    return NULL;
}
void Prey::breed(int i, int j){
        /*
        if(j>0 && board[i][j-1]==NULL){ board[i][j-1] = new Predator(); board[i][j]->setLaidTurns(0); }
        else if(j<size-1 && board[i][j+1]==NULL){ board[i][j+1] = new Predator(); board[i][j]->setLaidTurns(0); }
        else if(i > 0 && board[i-1][j]==NULL){ board[i-1][j] = new Predator(); board[i][j]->setLaidTurns(0); }
        else if(i<size-1 && board[i+1][j]==NULL){ board[i+1][j]= new Predator(); board[i][j]->setLaidTurns(0); }
        else{ }*/
}
void Prey::move(int i, int j){
    /*int choice = (rand() % 4) + 1;
    bool moveOn = false;
    if(board[i][j]->getIdentity()=='v'){
            do { 
                    switch(choice) {
                        case 1 :
                            if( j>0 && board[i][j-1]==NULL ){ 
                                    board[i][j]->setEatTurns(board[i][j]->getEatTurns()+1);
                                    board[i][j]->setLaidTurns(board[i][j]->getLaidTurns()+1);
                                    board[i][j-1] = board[i][j]; 
                                    board[i][j] = NULL;
                                    moveOn = true;
                                    board[i][j-1]->setTurns(timeStep);

                            }
                            else{
                                choice = (rand() % 4) + 1; 
                            }

                            break;
                            
                        case 2 :
                            if(j!=size-1 && board[i][j+1]==NULL){
                                board[i][j]->setEatTurns(board[i][j]->getEatTurns()+1);
                                board[i][j]->setLaidTurns(board[i][j]->getLaidTurns()+1);
                                board[i][j+1] = board[i][j]; 
                                board[i][j] = NULL;
                                moveOn = true;
                                board[i][j+1]->setTurns(timeStep);
                            }
                            else{
                                choice = (rand() % 4) + 1;  
                            }
                            break;
                        case 3 :
                            if(i > 0 && board[i-1][j]==NULL){
                                board[i][j]->setEatTurns(board[i][j]->getEatTurns()+1);
                                board[i][j]->setLaidTurns(board[i][j]->getLaidTurns()+1);
                                board[i-1][j] = board[i][j]; 
                                board[i][j] = NULL;  
                                moveOn = true;
                                board[i-1][j]->setTurns(timeStep);
                            }
                            else{
                                choice = (rand() % 4) + 1;   
                                }
                            break;
                        case 4 : 
                            if(i!=size-1 && board[i+1][j]==NULL){ 
                                board[i][j]->setEatTurns(board[i][j]->getEatTurns()+1);
                                board[i][j]->setLaidTurns(board[i][j]->getLaidTurns()+1);
                                board[i+1][j] = board[i][j];
                                board[i][j] = NULL;
                                moveOn = true;
                                board[i+1][j]->setTurns(timeStep); 
                            }
                            else{
                                choice = (rand() % 4) + 1;
                                } 
                            break;                
                }   
            
            } while (moveOn == false);*/
}
void Prey::eat(int i, int j){
    /*
        cout<<"beep-beep\n";
    */
}
void Prey::die(int i, int j){
        /*if (board[i][j]->getEatTurns()==4){
        delete board[i][j];
        board[i][j]=NULL;
    }*/
}
