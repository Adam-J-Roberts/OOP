#ifndef Animal_H
#define Animal_H
#include <iostream>
#include <string>



using namespace std;

class Animal
{
    

    protected:

        int steps;          /*Number of steps agent has taken*/
        char identity;      /*type of agent p=passive v=vicious*/
        int turns;          /*Number of steps agent has taken*/
        int laidTurns;      /*Steps since last breeding*/
        int eatTurns;

        
        char getIdentity();
        /**************************************************************
        * Description:  Getter for agents identity
        * Parameters:   No parameters required
        * Return Value: Char
        **************************************************************/
        void setIdentity(char identity);
                /**************************************************************
        * Description:  Setter for agents identity
        * Parameters:   Char identity
        * Return Value: Void
        **************************************************************/
        int getTurns();
        /**************************************************************
        * Description:  Getter for agents total steps
        * Parameters:   No parameters required
        * Return Value: Int
        **************************************************************/        
        void setTurns(int timeSteps);
        /**************************************************************
        * Description:  Setter for agents total steps
        * Parameters:   Total TimeSteps for simulation
        * Return Value: Void
        **************************************************************/
        virtual void eat(int i, int j);
        /**************************************************************
        * Description:  Agent eatting method
        * Parameters:   Int X and Y locations of agent
        * Return Value: Void
        **************************************************************/
        virtual Animal* adjacent(int i, int j);
        /**************************************************************
        * Description:  Checks adjecent cells for other agents
        * Parameters:   Int X and Y locations of agent
        * Return Value: Animal*
        **************************************************************/
        int getLaidTurns();
        /**************************************************************
        * Description:  Getter for steps since last breeding
        * Parameters:   No parameters required
        * Return Value: Int 
        **************************************************************/
        void setLaidTurns(int laidTurns);
        /**************************************************************
        * Description:  Setter for steps since last breeding
        * Parameters:   Int new number of turns since last breeding
        * Return Value: Void
        **************************************************************/
        int getEatTurns();
        /**************************************************************
        * Description:  Getter for number of turns since last meal
        * Parameters:   No parameters required
        * Return Value: Int
        **************************************************************/
        void setEatTurns(int eat);
        /**************************************************************
        * Description:  Setter for number of turns since last meal
        * Parameters:   Int new number of turns since last meal
        * Return Value: Void
        **************************************************************/
        virtual void move(int i, int j);
        /**************************************************************
        * Description:  Moves Agent
        * Parameters:   Int X and Y locations of agent
        * Return Value: Void
        **************************************************************/        
        virtual void breed(int i, int j);
        /**************************************************************
        * Description:  Causes agent to reproduce
        * Parameters:   Int X and Y locations of agent
        * Return Value: Void
        **************************************************************/
        virtual void die(int i, int j);
        /**************************************************************
        * Description:  Kills agent
        * Parameters:   Int X and Y locations of agent
        * Return Value: Void
        **************************************************************/


    public:
        Animal();
        /**************************************************************
        * Description:  Animal constructor
        * Parameters:   No parameters required
        * Return Value: New Animal
        **************************************************************/
        friend class Board;
        friend class Simulation;
};
#endif