#ifndef PREDATOR_H
#define PREDATOR_H
#include "Animal.h"
#include <iostream>
#include <string>
#include <cstdlib>



using namespace std;

class Predator : public Animal
{
    

    private:
        int eatTurns;
        Predator();
        int getEatTurns();
        char getIdentity();

    public:
        friend class Board;

};
#endif