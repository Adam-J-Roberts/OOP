#include "Animal.h"
#include "Predator.h"

//Predator::Predator(){}
Predator::Predator()
{

    eatTurns = 0;
    identity = 'v';
}
int Predator::getEatTurns(){
    return this->eatTurns;
}
char Predator::getIdentity()
{
    return this->Animal::getIdentity();
}
