#include <iostream>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <fstream>
#include <string>

#include "Animal.h"
#include "Prey.h"
#include "Predator.h"
#include "Board.h"


using namespace std;

int main()
{
    //cout << test << endl;
    int i = 12;
    Board* steve = new Board(3,0);// = new Animal();
    //Donation* d = new Donation("sucker", "contribution", "date");
    //Animal* test = new Predator();

return 0;
}