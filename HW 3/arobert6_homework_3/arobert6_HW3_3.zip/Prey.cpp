#include "Animal.h"
#include "Prey.h"

//Prey::Prey(){}
Prey::Prey()
{
    
    eatTurns = 0;
    identity = 'p';
}
char Prey::getIdentity()
{
    return this->Animal::getIdentity();
}


