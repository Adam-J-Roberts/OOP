#ifndef PREY_H_
#define PREY_H_
#include "Animal.h"
#include <iostream>
#include <string>
#include <cstdlib>


using namespace std;

class Prey : public Animal
{
    private:
        Prey();
        char getIdentity();


    public:
        friend class Board;
};
#endif