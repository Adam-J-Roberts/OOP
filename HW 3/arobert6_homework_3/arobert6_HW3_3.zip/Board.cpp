#include "Animal.h"
#include "Predator.h"
#include "Prey.h"
#include "Board.h"
#include <cstring>
////
//Known bugs:
//Work on seeding issue
Board::Board(int hunters, int hunted) 
    : size(3)/////sqrt((hunters*5)+(hunted*5)))
{
    predators = hunters;
    prey = hunted;


    //verify if random has been seeded
    //if(!seeded) {
        srand(time(NULL));
       // seeded = true;
   // }
    //determining size of board

    //generating board
    board = new Animal**[size];
    for(int i = 0; i < size; i++){
        board[i] = new Animal*[size];
    }
    for(int i = 0; i < size; i++){
        for(int j=0; j<size; j++){
            board[i][j]=NULL;

        }
    } 
    for(int i=0; i < hunters; i++){
        bool stop = false;
        do{
            int x = rand() % (size) + 0;
            int y = rand() % (size) + 0;
            if(board[x][y] == NULL){ //is_null_pointer<Animal*>::Animal*){
                Animal* temp = new Predator();
                board[x][y] = temp;
                stop = true;
            }
            else{
                stop = false;
            }
        }while(stop==false);
    }
    //generating prey
    for(int j=0; j < hunted; j++){
        bool stop = false;
        do{            
            int x = rand() % (size) + 0;
            int y = rand() % (size) + 0;
            if(board[x][y] == NULL){
                Animal* temp = new Prey();
                board[x][y] = temp;
                stop = true;
            }
            else{
                stop = false;
            }
        }while(stop==false);
    }
    //print();
    int step=0;
    cout << "Start\n";
    print();
    for(int i=0; i<9; i++){
        this->stepForward();
    }
}
//Stepping forward in time  Do random later!
void Board::stepForward(){
    timeStep++;
    cout << "Step:" << timeStep << endl;;
    for(int i=0;i<size;i++){
        for(int j=0; j<size;j++){            
            if(board[i][j] != NULL && board[i][j]->getTurns() != timeStep) //dynamic_cast<Animal*>()
            {   
                
                if(board[i][j]->getIdentity() == 'v'){
                    eat(i,j);
                    cout << "After eat( [" << i << "," << j << "] )\n";
                    print();
                    
                    if (board[i][j]->getEatTurns()==4){
                       // die(i,j);
                        //cout << "After die( [" << i << "," << j << "] )\n";
                        //print();
                    }
                    if(board[i][j] != NULL){
                        if(board[i][j]->getLaidTurns() == 8){
                            breed(i,j);
                            cout << "After breed( [" << i << "," << j << "] )\n";
                            print();


                        }
                        move(i,j);
                        cout << "After move( [" << i << "," << j << "] )\n";
                        print();


                    }
                }
            }
        }
    }
}
void Board::eat(int i, int j){
    //Animal* temp = adjacent(i,j);
    if(adjacent(i,j)==NULL){  }
    else{
        if(j>0 && board[i][j-1]!=NULL && board[i][j-1]->getIdentity() == 'p' ){ board[i][j-1] = NULL; board[i][j-1]->setEatTurns( 0 ); }
        else if(j<size-1 && board[i][j+1]!=NULL && board[i][j+1]->getIdentity() == 'p'){ board[i][j+1] = NULL; board[i][j-1]->setEatTurns( 0 ); }
        else if(i > 0 && board[i-1][j]!=NULL && board[i-1][j]->getIdentity() == 'p'){ board[i-1][j] = NULL; board[i][j-1]->setEatTurns( 0 ); }
        else if(i<size-1 && board[i+1][j]!=NULL && board[i+1][j]->getIdentity() == 'P'){ board[i+1][j] = NULL; board[i][j-1]->setEatTurns( 0 ); }
    }

}
void Board::move(int i, int j){
    int choice = (rand() % 4) + 1;
    bool moveOn = false;
    if(board[i][j]->getIdentity()=='v'){
            do { 
                    switch(choice) {
                        case 1 :
                            if( j>0 && board[i][j-1]==NULL ){ 
                                    board[i][j]->setEatTurns(board[i][j]->getEatTurns()+1);
                                    board[i][j]->setLaidTurns(board[i][j]->getLaidTurns()+1);
                                    board[i][j-1] = board[i][j]; 
                                    board[i][j] = NULL;
                                    moveOn = true;
                                    board[i][j-1]->setTurns(timeStep);

                            }
                            else{
                                choice = (rand() % 4) + 1; 
                            }

                            break;
                            
                        case 2 :
                            if(j!=size-1 && board[i][j+1]==NULL){
                                board[i][j]->setEatTurns(board[i][j]->getEatTurns()+1);
                                board[i][j]->setLaidTurns(board[i][j]->getLaidTurns()+1);
                                board[i][j+1] = board[i][j]; 
                                board[i][j] = NULL;
                                moveOn = true;
                                board[i][j+1]->setTurns(timeStep);
                            }
                            else{
                                choice = (rand() % 4) + 1;  
                            }
                            break;
                        case 3 :
                            if(i > 0 && board[i-1][j]==NULL){
                                board[i][j]->setEatTurns(board[i][j]->getEatTurns()+1);
                                board[i][j]->setLaidTurns(board[i][j]->getLaidTurns()+1);
                                board[i-1][j] = board[i][j]; 
                                board[i][j] = NULL;  
                                moveOn = true;
                                board[i-1][j]->setTurns(timeStep);
                            }
                            else{
                                choice = (rand() % 4) + 1;   
                                }
                            break;
                        case 4 : 
                            if(i!=size-1 && board[i+1][j]==NULL){ 
                                board[i][j]->setEatTurns(board[i][j]->getEatTurns()+1);
                                board[i][j]->setLaidTurns(board[i][j]->getLaidTurns()+1);
                                board[i+1][j] = board[i][j];
                                board[i][j] = NULL;
                                moveOn = true;
                                board[i+1][j]->setTurns(timeStep); 
                            }
                            else{
                                choice = (rand() % 4) + 1;
                                } 
                            break;                
                }   
            
            } while (moveOn == false);
    }
    //board[i][j]->setTurns(timeStep);

}
void Board::breed(int i, int j){
    if(board[i][j]->getIdentity() == 'v'){
        if(j>0 && board[i][j-1]==NULL){ board[i][j-1] = new Predator(); board[i][j]->setLaidTurns(0); }
        else if(j<size-1 && board[i][j+1]==NULL){ board[i][j+1] = new Predator(); board[i][j]->setLaidTurns(0); }
        else if(i > 0 && board[i-1][j]==NULL){ board[i-1][j] = new Predator(); board[i][j]->setLaidTurns(0); }
        else if(i<size-1 && board[i+1][j]==NULL){ board[i+1][j]= new Predator(); board[i][j]->setLaidTurns(0); }
        else{ }
    }

}
void Board::die(int i, int j){
    //cout << "die()\n";
    //cout << board[i][j]->getIdentity();
    //cout << board[i][j];//->getEatTurns();
    if (board[i][j]->getIdentity() == 'v' && board[i][j]->getEatTurns()==4){
        cout << "die()\n";
        delete board[i][j];
        board[i][j]=NULL;
    }
    
 
}
void Board::print(){
    for(int i=0; i<size; i++){
        for(int j=0; j<size; j++){
            if(board[i][j]!=NULL){
                cout << board[i][j]->getIdentity() << " ";
            }
            else{cout << board[i][j] << " "; }
            
        }
        cout << endl;
    }
    cout << endl;
}
Animal* Board::adjacent(int i, int j)
{
    if(j>0 && board[i][j-1]!=NULL){ return board[i][j-1]; }//
    else if(j<size-1 && board[i][j+1]!=NULL){ return board[i][j+1]; }//
    else if(i > 0 && board[i-1][j]!=NULL){ return board[i-1][j]; }//
    else if(i<size-1 && board[i+1][j]!=NULL){ return board[i+1][j]; }
    else{ return NULL; }
        

}

