#ifndef Animal_H
#define Animal_H
//#include "Board.h"
#include <iostream>
#include <string>
#include <cstdlib>


using namespace std;

class Animal
{
    

    protected:

        int steps;
        char identity;
        int turns;
        int laidTurns;
        int eatTurns;

        Animal();
        //Animal(int steps, char identity, int timeStep);
        virtual char getIdentity();
        //void setIdentity();
        int getTurns();
        void setTurns(int timeSteps);
        int getLaidTurns();
        void setLaidTurns(int laidTurns);
        int getEatTurns();
        void setEatTurns(int eat);

    public:
        //int getTime();
        friend class Board;
        

};
#endif