#include "Animal.h"


Animal::Animal(){
    this->steps = 0;
    //this->identity = identity;
    this->turns = 0;
    int laidTurns = 0;
}
char Animal::getIdentity(){
    return identity;
}
//void Animal::setIdentity(identity){
  //  this->identity=identity;
//}
int Animal::getTurns(){
    return turns;
}
void Animal::setTurns(int timeStep){
    turns = timeStep;
}
int Animal::getLaidTurns(){
    return laidTurns++;
}
void Animal::setLaidTurns(int laidTurns){
    this->laidTurns=laidTurns;
}
int Animal::getEatTurns(){
    return eatTurns;
}
void Animal::setEatTurns(int eat){
    eatTurns = eat;
}