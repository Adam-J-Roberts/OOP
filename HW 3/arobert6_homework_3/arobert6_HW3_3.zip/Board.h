#ifndef Board_H
#define Board_H

#include <iostream>
#include <string>
#include <cstdlib>
#include <math.h>
#include <time.h>
#include "Animal.h"

using namespace std; // Don't do this! Remove before handing in

class Board
{
    private:
        const int size;
        int timeStep;
        int predators;
        int prey;
        Animal*** board;
        void stepForward();
        void move(int i, int j);
        //int getEatTurns();
        void eat(int i, int j);
        void breed(int i, int j);
        void die(int i, int j);
        void print();
        Animal* adjacent(int i, int j);

        //static bool seeded;
        //Board();

    public:
        
        Board(int hunters, int hunted); //predator, prey
        friend class Animal;


};
#endif
